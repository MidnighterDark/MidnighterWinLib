//Copyright Midnighter & MidnighterDark & ONION & ONION-Studio.
//If you are not working with the source code, PLEASE DO NOT MODIFY THIS FILE.
#ifndef WINLIB_DRAWABLE_HPP
#define WINLIB_DRAWABLE_HPP
#include <WL/Core/Core.hpp>
#include <WL/Core/Vector.hpp>
#include <WL/Core/Rect.hpp>
#include <WL/Window/Window.hpp>
WL_NAMESPACE_BEGIN
class Drawable {
	friend class Window;
protected:
	Vector2i _Pos;
	Vector2i _Size;
	Vector2i _Root;
	Vector2f _Scale;
	float    _Angle;
	IntRect  _Rect;
	HDC      _Hdc = NULL;
	HDC      _MaskHdc = NULL;
	HBITMAP  _hHdcBitmap = NULL;
	HBITMAP  _hOldHdcBitmap = NULL;
	~Drawable();
public:
	//For get element's position
	Vector2i getPosition() const;
	//For get element's scale
	Vector2f getScale() const;
	//For get element's root
	Vector2i getRoot() const;
	//For get element's size
	Vector2i getSize() const;
	//For get element's global bounds in IntRect
	IntRect  getGlobalBounds() const;
	//For get element's rotation
	float    getAngle() const;
	//For setting element's global position
	void     setPosition(Int32 x, Int32 y);
	//For setting element's scale 
	void     setScale(float x, float y);
	//To adjust the size of an element in pixels
	//If the pixel size is smaller than the image size, the image will crop all pixels outside the area
	void     setSize(Int32 x, Int32 y);
	//For setting element's root
	void     setRoot(Int32 x, Int32 y);
	//For setting element's rotation
	void     setAngle(float newAngle);
};
WL_NAMESPACE_END
#endif //WINLIB_DRAWABLE_HPP